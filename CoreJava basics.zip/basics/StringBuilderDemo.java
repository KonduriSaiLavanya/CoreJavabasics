package com.csscorp.basics;

public class StringBuilderDemo {

	public static void main(String[] args) {
		
	
	StringBuilder sb=new StringBuilder();
	
	sb.append("This is a test");
	sb.append(" for String Builder class");
	System.out.println(sb);
	}
}
