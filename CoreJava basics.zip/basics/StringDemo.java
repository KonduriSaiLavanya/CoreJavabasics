package com.csscorp.basics;

public class StringDemo {
	public static void main(String[] args) {
		
		String name="JaVa";
		String tech;
		tech="Python";
		
		String trimDem="            testTrim          ";
		
		String db=new String("Oracle");
		String splitDemo="apple,orange,mango";
		String[] fruits=splitDemo.split(",");
		System.out.println(fruits[0]);
		System.out.println(fruits[1]);
		System.out.println(fruits[2]);
		
		System.out.println("length:"+db.length());
		System.out.println("toUpper: "+tech.toUpperCase());
		System.out.println("toLower: "+tech.toLowerCase());
		System.out.println("contains: "+name.contains("v"));
		System.out.println("without Trim: "+trimDem);
		System.out.println("Trim: "+trimDem.trim());
		System.out.println("Split: "+trimDem.split("t")[1]);
		System.out.println("SubString: "+db.substring(3));
		
		if(name.equals(tech)) {
			System.out.println("The string value is equal");
		}else {
			System.out.println("The string value is not equal");
		}
	}
}
