package com.csscorp.oops.inheritance.simple;

public class LaptopMain {
	public static void main(String[] args) {
		Lenovo lenovo=new Lenovo(45000.00,"Lv001","3rd Gen I5");
		lenovo.getLenovoDetails();
		
	}
}
