package com.csscorp.oops.abstraction;



public class Honda extends Bike{
	
	
	public Honda() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Honda(String color, String type) {
		super(color, type);
		// TODO Auto-generated constructor stub
	}

	public void price(){
		System.out.println("Price: 40,000.00");
	}

}
