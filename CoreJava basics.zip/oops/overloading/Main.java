package com.csscorp.oops.overloading;

import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
		ArrayList<Trainee> trainees=new ArrayList<>();
		trainees.add(new Trainee(123,"Charles","Male",21));
		trainees.add(new Trainee(124,"Christy","FeMale",20));
		trainees.add(new Trainee(125,"Charles","Male",20));
		
		Batch batch=new Batch(10,"JavaBatch",trainees);
		System.out.println(batch.getTrainee(123));
		
		System.out.println(batch.getTrainees(21).toString());
		System.out.println(batch.getTrainees("Male").toString());
		

	}

}
